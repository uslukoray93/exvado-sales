import * as React from "react"
import * as VisuallyHiddenPrimitive from "@radix-ui/react-visually-hidden"

export const VisuallyHidden = VisuallyHiddenPrimitive.Root

export default VisuallyHidden
